# Mall Wayfinder – mobile app

`www/` = poori app (offline, koi CDN nahi). Do tareeke:

## 1) Sabse tez: PWA (phone me install)
1. `www/` folder ko kisi HTTPS hosting par daalo (Netlify Drop, Vercel, GitHub Pages).
2. Phone ke Chrome me link kholo -> menu -> **Add to Home screen / Install app**.
3. Ek baar khulne ke baad offline bhi chalega. Voice (mic) Chrome me kaam karta hai.

## 2) Real Android APK (Capacitor)
Zaroorat: Node 20+, Android Studio.
```bash
npm install
npx cap add android
npx cap sync android
npx cap open android      # Android Studio khulega -> Run ▶ ya Build > Build APK
```
Voice ke liye `AndroidManifest.xml` me ye line add karo (`<manifest>` ke andar):
```xml
<uses-permission android:name="android.permission.RECORD_AUDIO" />
```
Code me native speech plugin pehle se hooked hai (`@capacitor-community/speech-recognition`).

App icon badalna ho to `icon-source-1024.png` ko `@capacitor/assets` se use karo:
`npx @capacitor/assets generate --android`

## iOS
`npm i @capacitor/ios && npx cap add ios && npx cap open ios` (Mac + Xcode chahiye).

## Emergency mode
Sidebar me **Navigate / Emergency mode** switch, aur map par lal **Emergency** button.
- Current location se **saare routes** dono exits tak dikhte hain (A, B, C…), user khud choose karta hai.
- Default me har exit ke 3 routes; **Show all N routes** se baaki bhi khulte hain.
- Lifts kabhi use nahi hote, aur shops ke andar se route nahi jata.
- Kisi exit ko **blocked** mark kar sakte ho, ya stairs/escalator "Can't use" karke routes dobara bante hain.
